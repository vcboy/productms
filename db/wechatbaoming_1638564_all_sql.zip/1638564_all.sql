﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `wx_admin`;
CREATE TABLE `wx_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL COMMENT '用户登录名',
  `password` varchar(32) DEFAULT NULL COMMENT '密码',
  `name` varchar(100) DEFAULT NULL COMMENT '姓名',
  `gender` tinyint(4) DEFAULT '1' COMMENT '性别(0：女；1：男；)',
  `correspondence_id` int(11) DEFAULT NULL COMMENT '函授站',
  `role_name` varchar(64) DEFAULT NULL COMMENT '角色名称',
  `is_delete` tinyint(4) DEFAULT '0' COMMENT '是否删除',
  `my_quickentry` text COMMENT '快捷入口',
  `courseids` varchar(255) DEFAULT NULL COMMENT '任课老师课程',
  `disciplineids` varchar(255) DEFAULT NULL COMMENT '任课老师的专业',
  `p_id` tinyint(2) NOT NULL,
  `level` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

insert into `wx_admin`(`id`,`username`,`password`,`name`,`gender`,`correspondence_id`,`role_name`,`is_delete`,`my_quickentry`,`courseids`,`disciplineids`,`p_id`,`level`) values
('1','admin','96e79218965eb72c92a549dd5a330112','超级管理员','1',null,'zongadming','0','{"75":{"id":75,"name":"\\u4fee\\u6539\\u5bc6\\u7801","url":"admin\\/edit-password"}}','','','1','1'),
('2','test','96e79218965eb72c92a549dd5a330112','测试账号','1',null,null,'0',null,null,null,'1','0'),
('3','member','96e79218965eb72c92a549dd5a330112','1','1',null,null,'0',null,null,null,'2','0');
DROP TABLE IF EXISTS  `wx_auth_assignment`;
CREATE TABLE `wx_auth_assignment` (
  `item_name` varchar(64) NOT NULL,
  `user_id` varchar(64) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `created_at` (`created_at`),
  KEY `item_name` (`item_name`),
  CONSTRAINT `wx_auth_assignment_ibfk_2` FOREIGN KEY (`item_name`) REFERENCES `wx_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='管理员授权表';

insert into `wx_auth_assignment`(`item_name`,`user_id`,`created_at`) values
('zongadming','1','1470623219');
DROP TABLE IF EXISTS  `wx_auth_item`;
CREATE TABLE `wx_auth_item` (
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `type` int(11) NOT NULL COMMENT '类型{1：角色；2：权限；}',
  `description` text COMMENT '描述',
  `rule_name` varchar(64) DEFAULT NULL COMMENT '规则名称',
  `data` text COMMENT '数据',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL COMMENT '权限所属菜单',
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `type` (`type`),
  KEY `name` (`name`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `wx_auth_item_ibfk_2` FOREIGN KEY (`rule_name`) REFERENCES `wx_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='管理权权限条目';

insert into `wx_auth_item`(`name`,`type`,`description`,`rule_name`,`data`,`created_at`,`updated_at`,`menu_id`) values
('admin_create','2','用户添加',null,null,null,null,'33'),
('admin_delete','2','用户删除',null,null,null,null,'33'),
('admin_quickentry','2','快捷入口设置',null,null,null,null,'35'),
('admin_update','2','用户修改',null,null,null,null,'33'),
('certificate_index','2','证书领取',null,null,null,null,'64'),
('channel_create','2','添加频道',null,null,null,null,'36'),
('course_index','2','课程管理查看',null,null,null,null,'49'),
('grade_index','2','成绩管理',null,null,null,null,'62'),
('itemspreset_index','2','转码查看',null,null,null,null,'40'),
('itemstype/index','2','视频分类查看',null,null,null,null,'39'),
('itemsupload_index','2','视频上传',null,null,null,null,'43'),
('items_index','2','视频查看',null,null,null,null,'41'),
('jf_index','2','积分管理',null,null,null,null,'61'),
('jianding_del','2','鉴定报名删除',null,null,null,null,'54'),
('jianding_index','2','鉴定报名管理',null,null,null,null,'54'),
('jianding_nosh','2','商务委人才未审核管理',null,null,null,null,'67'),
('lession_index','2','课程管理',null,null,null,null,'57'),
('member_index','2','会员管理',null,null,null,null,'60'),
('menu_create','2','菜单添加',null,null,null,null,'32'),
('menu_delete','2','菜单删除',null,null,null,null,'32'),
('menu_taxis','2','菜单排序',null,null,null,null,'32'),
('menu_update','2','菜单修改',null,null,null,null,'32'),
('news_index','2','公告信息',null,null,null,null,'66'),
('password_update','2','修改密码',null,null,null,null,'75'),
('permission_create','2','权限添加',null,null,null,null,'30'),
('permission_delete','2','权限删除',null,null,null,null,'30'),
('permission_update','2','权限修改',null,null,null,null,'30'),
('plan_del','2','活动删除',null,null,null,null,'55'),
('plan_index','2','活动管理',null,null,null,null,'55'),
('platform_index','2','平台管理',null,null,null,null,'52'),
('resource_index','2','资料管理',null,null,null,null,'63'),
('role_create','2','角色添加',null,null,null,null,'31'),
('role_delete','2','角色删除',null,null,null,null,'31'),
('role_permission','2','角色权限设置',null,null,null,null,'31'),
('role_update','2','角色修改',null,null,null,null,'31'),
('shortcut_update','2','设置快捷方式',null,null,null,null,'74'),
('teacher_index','2','教师管理',null,null,null,null,'58'),
('zongadming','1','总管理员',null,null,null,null,null);
DROP TABLE IF EXISTS  `wx_auth_item_child`;
CREATE TABLE `wx_auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='管理员权限关系表';

insert into `wx_auth_item_child`(`parent`,`child`) values
('zongadming','admin_create'),
('zongadming','admin_delete'),
('zongadming','admin_quickentry'),
('zongadming','admin_update'),
('teacher','enroll_score'),
('zongadming','jf_index'),
('zongadming','jianding_del'),
('zongadming','jianding_index'),
('zongadming','jianding_nosh'),
('zongadming','lession_index'),
('zongadming','member_index'),
('zongadming','menu_create'),
('zongadming','menu_delete'),
('zongadming','menu_taxis'),
('zongadming','menu_update'),
('zongadming','news_index'),
('teacher','notice_create'),
('teacher','notice_delete'),
('teacher','notice_edit'),
('zongadming','permission_create'),
('zongadming','permission_delete'),
('zongadming','permission_update'),
('zongadming','plan_del'),
('zongadming','plan_index'),
('zongadming','resource_index'),
('zongadming','role_create'),
('zongadming','role_delete'),
('zongadming','role_permission'),
('zongadming','role_update'),
('zongadming','teacher_index');
DROP TABLE IF EXISTS  `wx_auth_rule`;
CREATE TABLE `wx_auth_rule` (
  `name` varchar(64) NOT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `name` (`name`),
  KEY `created_at` (`created_at`),
  KEY `updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='管理员权限规则表';

DROP TABLE IF EXISTS  `wx_jf`;
CREATE TABLE `wx_jf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) DEFAULT NULL COMMENT '会员id',
  `jf` float DEFAULT NULL COMMENT '积分',
  `way` varchar(64) DEFAULT NULL COMMENT '获取方式',
  `datetime` varchar(32) DEFAULT NULL COMMENT '积分日期',
  PRIMARY KEY (`id`),
  KEY `mid` (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='积分表';

insert into `wx_jf`(`id`,`mid`,`jf`,`way`,`datetime`) values
('1','1','5','register',null),
('2','2','1','register',null),
('3','3','5','register',null),
('4','4','5','register',null),
('5','5','5','register','1507558399'),
('6','6','5','register','1507558551'),
('7','7','5','register','1509194477'),
('8','8','5','register','1510109035'),
('9','9','5','register','1514119080'),
('10','10','5','register','1515396376');
DROP TABLE IF EXISTS  `wx_jianding_table`;
CREATE TABLE `wx_jianding_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) DEFAULT NULL COMMENT '活动id',
  `company` varchar(128) DEFAULT NULL COMMENT '申报单位',
  `name` varchar(64) DEFAULT NULL COMMENT '姓名',
  `sex` tinyint(4) DEFAULT NULL COMMENT '1：男 0：女',
  `nation` varchar(32) DEFAULT NULL COMMENT '民族',
  `birthday` varchar(32) DEFAULT NULL COMMENT '出生年月',
  `sfz` varchar(64) DEFAULT NULL COMMENT '身份证',
  `bkzs` varchar(64) DEFAULT NULL COMMENT '报考证书',
  `bkfx` varchar(128) DEFAULT NULL COMMENT '报考方向',
  `zsdj` varchar(64) DEFAULT NULL COMMENT '证书等级',
  `tel` varchar(32) DEFAULT NULL COMMENT '联系方式',
  `education` text COMMENT '教育经历',
  `job` text COMMENT '工作经历',
  `score` float DEFAULT '0' COMMENT '成绩分数',
  `is_sh` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否审核',
  `is_pay` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否付款 0未付 1已付',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `plan_id` (`plan_id`),
  KEY `sfz` (`sfz`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='电子商务专业人才鉴定申请表';

insert into `wx_jianding_table`(`id`,`plan_id`,`company`,`name`,`sex`,`nation`,`birthday`,`sfz`,`bkzs`,`bkfx`,`zsdj`,`tel`,`education`,`job`,`score`,`is_sh`,`is_pay`,`is_delete`) values
('8','9','aaa','bbb','1','d','2007/1/1','123654654321','aa','cc','bb','03265555555','[["23","23","23","Mrs."]]','[["234","432","234","Mr."]]',null,'1','0','1'),
('9','9','浙江盛通','吴世勋','1','汉','2005/1/1','23444442654321','123','123','123','123','[["123","123","123","Mrs."]]','[["123","123","123","Sir"]]',null,'1','0','0'),
('10','9','北京百度','李艳红','1','汉','2007/12/1','2342343123456','122','33','44','33','[["44","33","44","Ms."]]','[["55","66","77","Ms."]]',null,'1','0','0'),
('11','9','深圳腾讯','马画藤','1','汉','2009/1/11','987654321','1234','534','643','23','[["345","644","657","Ms."]]','[["776","67","67","Ms."]]',null,'1','0','0'),
('12','9','广州恒大','许家银','1','汉','2005/12/1','777555','444','66','55','77','[["99","88","77","Ms."],["99","88","77","Ms."]]','[["oo","uu","tt","Ms."]]','98','1','0','0'),
('13','9','浙江阿里','马红','1','汉','2017/1/1','333333321','123','321','312','132','[["123","123","123","Mr."]]','[["453","45","345","Mr."]]','55','1','0','0'),
('14','9','宁波大优','陈思敏','1','汉','2002/11/17','23423423','4','234','234','234234234','[["2","2","33","42"]]','[["34234","234","2342","34"]]','0','1','0','0'),
('15','9','天津泰达','王明明','1','汉','2007/1/1','123654789632547','11','33','22','44','[["55","66","77","88"]]','[["77","66","55","33"]]','0','0','0','0'),
('16','8','浙江工商','陈志忠','1','汗','2007/4/8','330227125698563214','计算机','技能','3级','13696325411','[["1996.9-1999.7","高专","计算机","职高"]]','[["2001.3-现在","宁波公司","技工","莆田"]]','0','0','0','1'),
('17','8','AA','BB','1','CC','2005/1/1','123654456321','11','33','22','1369696666','[["113","33","44","55"]]','[["66","77","88",""]]','0','0','0','1'),
('18','8','AAA','BBB','1','CCC','2006/1/1','12365445632122','DDD','FFF','EEE','GGG','[["1968","333","222","111"]]','[["1999","66","77","88"]]','0','0','0','1'),
('19','8','A','B','1','C','2006/1/1','789654123654','222','4','33','4','[["234","34","34","324"]]','[["3","2","2","2"]]','0','0','0','1'),
('20','9','北京国安','司马懿','1','汉','1953/11/1','330224195311012523','商务','啊啊','一级','36996666','[["1982","北大","计算机","本科"]]','[["1998","北京大学","教师","硕士"]]','88','0','0','0'),
('21','9','宁波市镇海区吉博培训学校','辛可攀','1','汉','1993/11/20','23113119931119452X','没有啊','电商课程','没有','18868936163','[["2012-2016","哈尔滨剑桥学院","学前教育","学士"]]','[["2017.3","宁波市镇海区吉博培训学校","教务",""]]','0','0','0','0');
DROP TABLE IF EXISTS  `wx_lession`;
CREATE TABLE `wx_lession` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL COMMENT '课程名称',
  `img` varchar(128) DEFAULT NULL COMMENT '封面',
  `description` text COMMENT '描述',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='课程表';

insert into `wx_lession`(`id`,`name`,`img`,`description`,`is_delete`) values
('1','电子商务','','电子商务','0');
DROP TABLE IF EXISTS  `wx_mark`;
CREATE TABLE `wx_mark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) DEFAULT NULL COMMENT '会员id',
  `course_score` tinyint(4) NOT NULL DEFAULT '0' COMMENT '课程评分',
  `teacher_score` tinyint(4) NOT NULL DEFAULT '0' COMMENT '教师评分',
  `teacher_id` int(11) DEFAULT NULL COMMENT '教师id',
  `course_id` int(11) DEFAULT NULL COMMENT '课程id',
  `datetime` int(11) DEFAULT NULL COMMENT '创建时间',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  `message` text COMMENT '评论',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='课程教师评分表';

insert into `wx_mark`(`id`,`mid`,`course_score`,`teacher_score`,`teacher_id`,`course_id`,`datetime`,`is_delete`,`message`) values
('9','5','4','2','1','1','1508399599','0','asdf'),
('10','5','5','3','1','1','1508499599','0','asdf'),
('11','5','32','33','1','1','1508499599','0','asdf');
DROP TABLE IF EXISTS  `wx_member`;
CREATE TABLE `wx_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL COMMENT '姓名',
  `cid` varchar(64) DEFAULT NULL COMMENT '身份证',
  `tel` varchar(32) DEFAULT NULL COMMENT '手机号码',
  `username` varchar(64) DEFAULT NULL COMMENT '用户名',
  `pass` varchar(64) DEFAULT NULL COMMENT '密码',
  `jf` float DEFAULT NULL COMMENT '积分',
  `source` tinyint(4) DEFAULT NULL COMMENT '数据来源(哪类报名)',
  `sid` int(11) DEFAULT NULL COMMENT '对应报名id',
  `datetime` varchar(32) DEFAULT NULL COMMENT '注册日期',
  `sfz_path` varchar(64) DEFAULT NULL COMMENT '身份证路径',
  `pic_path` varchar(64) DEFAULT NULL COMMENT '照片路径',
  `getway` tinyint(4) DEFAULT '1' COMMENT '证书领取方式 1:自取 2:快递',
  `address` varchar(255) DEFAULT NULL COMMENT '寄送地址',
  `express_name` varchar(128) DEFAULT NULL,
  `express_tel` varchar(32) DEFAULT NULL,
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员表';

insert into `wx_member`(`id`,`name`,`cid`,`tel`,`username`,`pass`,`jf`,`source`,`sid`,`datetime`,`sfz_path`,`pic_path`,`getway`,`address`,`express_name`,`express_tel`,`is_delete`) values
('1','234','23444442654321','123','23444442654321','654321','5','2','9',null,null,null,'1','',null,null,'1'),
('2','234','23444442654321','123','23444442654321','654321','5','2','9',null,null,null,'1','',null,null,'0'),
('3','aaa','2342343123456','33','2342343123456','123456','5','2','10',null,null,null,'1','',null,null,'0'),
('4','66','987654321','23','987654321','654321','5','2','11',null,null,null,'1','',null,null,'0'),
('5','ee2124433','777555','1356666444','777555','777555','5','2','12',null,'./upload/sfz/777555','./upload/zj/777555.jpg','2','123','abc','123123','0'),
('6','dd','333333321','132','333333321','333321','5','2','13','1507558551',null,null,'1','',null,null,'0'),
('7','罗伊人','330221955544220','234234234','23423423','423423','5','2','14','1509194477',null,null,'1','',null,null,'0'),
('8','荀青春','789654123654','13696969878','789654123654','123654','5','2','19','1510109035',null,null,'1',null,null,null,'0'),
('9','司马懿','330224195311012523','36996666','330224195311012523','012523','5','2','20','1514119080','./upload/sfz/330224195311012523',null,'1',null,null,null,'0'),
('10','辛可攀','23113119931119452X','18868936163','23113119931119452X','19452X','5','2','21','1515396376',null,null,'2','软件学院','辛可攀','18868936163','0');
DROP TABLE IF EXISTS  `wx_menu`;
CREATE TABLE `wx_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL COMMENT '名称',
  `parent` int(11) DEFAULT '0' COMMENT '上级菜单',
  `route` varchar(256) DEFAULT NULL,
  `taxis` int(11) DEFAULT '0' COMMENT '排序字段 默认0,以数字倒序排列',
  `data` text,
  `url` varchar(100) DEFAULT NULL COMMENT '菜单链接地址',
  PRIMARY KEY (`id`),
  KEY `parent` (`parent`),
  KEY `name` (`name`),
  KEY `route` (`route`(255)),
  KEY `order` (`taxis`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 COMMENT='系统管理员菜单权限表\r\n';

insert into `wx_menu`(`id`,`name`,`parent`,`route`,`taxis`,`data`,`url`) values
('29','系统设置','0',null,'20',null,''),
('30','权限管理','29',null,null,null,'permission-form/index'),
('31','角色管理','29',null,null,null,'role-form/index'),
('32','菜单管理','29',null,null,null,'menu/index'),
('33','用户管理','29',null,null,null,'admin/index'),
('34','设置快捷方式','29',null,'1',null,'shortcut/index'),
('35','修改密码','29',null,'2',null,'admin/edit-password'),
('39','分类设置','38',null,'42',null,'items-type/index'),
('40','转码设置','38',null,'41',null,'items-preset/index'),
('41','视频管理','38',null,null,null,'items/index'),
('43','视频上传','38',null,null,null,'items-upload/index'),
('49','直播管理','37',null,null,null,'course/index'),
('51','平台管理','29',null,null,null,'platform/index'),
('52','平台管理','37',null,null,null,'platform/index'),
('53','在线报名','0',null,'40',null,''),
('54','商务委人才申请-已审核','53',null,'14',null,'jianding/index'),
('55','活动管理','53',null,'20',null,'plan/index'),
('56','教务管理','0',null,'39',null,''),
('57','课程管理','56',null,'9',null,'lession/index'),
('58','教师管理','56',null,'8',null,'teacher/index'),
('59','会员管理','0',null,'38',null,''),
('60','会员管理','59',null,null,null,'member/index'),
('61','积分管理','59',null,null,null,'jf/index'),
('62','成绩管理','56',null,'7',null,'grade/index'),
('63','资料管理','56',null,'6',null,'resource/index'),
('64','证书领取','56',null,'5',null,'certificate/index'),
('66','公告信息','56',null,'4',null,'news/index'),
('67','商务委人才申请-未审核','53',null,'15',null,'jianding/nosh');
DROP TABLE IF EXISTS  `wx_news`;
CREATE TABLE `wx_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL COMMENT '标题',
  `content` text COMMENT '内容',
  `pic` varchar(128) DEFAULT NULL COMMENT '图片',
  `attachment` varchar(255) DEFAULT NULL COMMENT '附件',
  `datetime` int(11) DEFAULT NULL COMMENT '日期',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='新闻表';

insert into `wx_news`(`id`,`title`,`content`,`pic`,`attachment`,`datetime`,`is_delete`) values
('1','丁薛祥接任中央直属机关工委书','丁薛祥，男，汉族，1962年9月生，江苏南通人，1982年8月参加工作，1984年10月加入中国共产党，复旦大学管理学院行政管理专业毕业，在职研究生学历，理学硕士学位，教授级高级工程师。

　　现任中央政治局委员、中央书记处书记，中央办公厅主任兼国家主席办公室主任，中央直属机关工委书记。

　　1978-1982年　东北重型机械学院机械工程系锻压工艺及设备专业学习

　　1982-1984年　上海材料研究所九室科研人员

　　1984-1988年　上海材料研究所办公室副主任、团委书记

　　1988-1992年　上海材料研究所办公室主任、宣传部主任

　　1992-1994年　上海材料研究所九室主任（其间：1993.09-1993.12上海市委党校中青年干部培训班学习）',null,null,'1508499599','0'),
('2','丁薛祥接任中央直属机关工委书','丁薛祥，男，汉族，1962年9月生，江苏南通人，1982年8月参加工作，1984年10月加入中国共产党，复旦大学管理学院行政管理专业毕业，在职研究生学历，理学硕士学位，教授级高级工程师。

　　现任中央政治局委员、中央书记处书记，中央办公厅主任兼国家主席办公室主任，中央直属机关工委书记。

　　1978-1982年　东北重型机械学院机械工程系锻压工艺及设备专业学习

　　1982-1984年　上海材料研究所九室科研人员

　　1984-1988年　上海材料研究所办公室副主任、团委书记

　　1988-1992年　上海材料研究所办公室主任、宣传部主任

　　1992-1994年　上海材料研究所九室主任（其间：1993.09-1993.12上海市委党校中青年干部培训班学习）',null,null,'1508499999','0');
DROP TABLE IF EXISTS  `wx_order`;
CREATE TABLE `wx_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(32) NOT NULL COMMENT '订单号',
  `price` float NOT NULL COMMENT '价格',
  `order_time` varchar(16) NOT NULL COMMENT '订单时间',
  `state` tinyint(4) NOT NULL COMMENT '支付状态：0：处理中；1：支付成功',
  `mid` int(11) NOT NULL COMMENT '会员id',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mid` (`mid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='订单表';

DROP TABLE IF EXISTS  `wx_plan`;
CREATE TABLE `wx_plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL COMMENT '活动名称',
  `tabletype` tinyint(4) DEFAULT NULL COMMENT '报名类型',
  `img` varchar(128) DEFAULT NULL COMMENT '图片',
  `jf` float DEFAULT NULL COMMENT '活动积分',
  `fee` float DEFAULT NULL COMMENT '费用',
  `description` text COMMENT '活动描述',
  `enddate` varchar(32) DEFAULT NULL COMMENT '报名结束日期',
  `course_id` int(11) DEFAULT NULL COMMENT '课程id',
  `teacher_id` int(11) DEFAULT NULL COMMENT '老师id',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='活动计划表';

insert into `wx_plan`(`id`,`name`,`tabletype`,`img`,`jf`,`fee`,`description`,`enddate`,`course_id`,`teacher_id`,`is_delete`) values
('1','2017年08月活动','1',null,'10','100','安安','2017/08/31','1','1','1'),
('3','啊啊啊啊','1','','2',null,'','2017/08/23','1','1','1'),
('4','啊啊啊啊','1','','2',null,'','2017/08/23','1','1','1'),
('5','啊啊啊啊','1','','2',null,'','2017/08/23','1','1','1'),
('6','啊啊啊啊','1','','2','100','','2017/08/23','1','1','1'),
('7','啊啊啊啊','1','','2',null,'','2017/08/23','1','1','1'),
('8','阿斯顿发送到','2','','10','59','','','1','1','1'),
('9','美国营销国际协会（SMEI）中国峰会暨营销科学与创新人才','2','/uploads/201712200658-890.jpg','10','99','','','1','1','0'),
('10','2017年7月电子商务职业资格鉴定','1','/uploads/201712200511-453.jpg','20','100','','','1','1','0');
DROP TABLE IF EXISTS  `wx_platform`;
CREATE TABLE `wx_platform` (
  `id` tinyint(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `private_key` varchar(64) DEFAULT NULL COMMENT '私钥',
  `public_key` varchar(64) DEFAULT NULL COMMENT '公钥',
  `describe` varchar(255) DEFAULT NULL,
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

insert into `wx_platform`(`id`,`name`,`private_key`,`public_key`,`describe`,`is_delete`) values
('1','麦能网','bbb','dd','ee','0'),
('3','自考平台','zjnep20170718','zjnep','人','0');
DROP TABLE IF EXISTS  `wx_teacher`;
CREATE TABLE `wx_teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) DEFAULT NULL COMMENT '姓名',
  `phone` varchar(32) DEFAULT NULL COMMENT '电话',
  `course_id` int(11) DEFAULT NULL COMMENT '课程id',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

insert into `wx_teacher`(`id`,`name`,`phone`,`course_id`,`is_delete`) values
('1','周鑫鑫','12366659874','1','0');
DROP TABLE IF EXISTS  `wx_zyzgjd_table`;
CREATE TABLE `wx_zyzgjd_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) DEFAULT NULL COMMENT '活动id',
  `name` varchar(64) DEFAULT NULL COMMENT '姓名',
  `sex` tinyint(4) DEFAULT NULL COMMENT '1：男 0：女',
  `birthday` varchar(32) DEFAULT NULL COMMENT '出生年月',
  `edu_level` tinyint(4) DEFAULT NULL COMMENT '文化程度',
  `card_type` tinyint(4) DEFAULT NULL COMMENT '证件类型',
  `sfz` varchar(64) DEFAULT NULL COMMENT '证件号码',
  `nation` varchar(128) DEFAULT NULL COMMENT '户籍所在地',
  `hukou_type` tinyint(4) DEFAULT NULL COMMENT '户口性质',
  `company` varchar(128) DEFAULT NULL COMMENT '单位名称',
  `address` varchar(128) DEFAULT NULL COMMENT '通讯地址',
  `zipcode` varchar(16) DEFAULT NULL COMMENT '邮政编码',
  `tel` varchar(32) DEFAULT NULL COMMENT '联系电话',
  `phone` varchar(32) DEFAULT NULL COMMENT '手机号码',
  `email` varchar(64) DEFAULT NULL COMMENT '电子邮件',
  `zhiye_type` tinyint(4) DEFAULT NULL COMMENT '现职业资格',
  `zhicheng_type` tinyint(4) DEFAULT NULL COMMENT '现职称',
  `sbzy` varchar(128) DEFAULT NULL COMMENT '申报职业',
  `sbjb` tinyint(4) DEFAULT NULL COMMENT '申报级别',
  `examtype` tinyint(4) DEFAULT NULL COMMENT '考试类型',
  `khkm` tinyint(4) DEFAULT NULL COMMENT '考核科目',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='国家职业资格鉴定申请表';

SET FOREIGN_KEY_CHECKS = 1;

